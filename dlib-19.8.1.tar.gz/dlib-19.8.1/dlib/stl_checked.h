// Copyright (C) 2008  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_STL_CHECKEd_HEADER
#define DLIB_STL_CHECKEd_HEADER

#include "stl_checked/std_vector_c.h"

#endif // DLIB_STL_CHECKEd_HEADER


